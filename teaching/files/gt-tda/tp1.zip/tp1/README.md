# Getting ready
1. Right-clic on the folder tp1 and open it with Visual Studio Code
2. Clic on 1.ipynb in Visual Studio Code and run the first cell
3. Select 'Python Environments...'
4. Clic on 'Create Python Environment'
5. Clic on 'Venv'
6. Clic on the version of Python in '/usr/bin/python3'
7. Select 'requirements.txt' as dependencies to install
8. Wait for the kernel to install packages (it may take a few minutes)
9. You are all set.
10. If you want to install a new package named xyz, type `pip install xyz` in a code cell in the notebook and run it.